package in.Meghana.JwtUtil;
//Handles login requests and returns JWT.

import java.io.Serializable;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@RestController
// request mapping is used to map the url
@RequestMapping("/auth")
public class AuthController {

	//AuthenticationManager: Spring Security class for handling authentication.
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;  //generating jwt tokens

    //constructor
    public AuthController(AuthenticationManager authenticationManager, JwtService jwtService) {
        this.authenticationManager = authenticationManager;
        this.jwtService = jwtService;
    }

    @PostMapping("/login")
    // here RequestBody is used to Accept JSON (or XML) data in HTTP requests
    public ResponseEntity<AuthResponse> login(@RequestBody AuthRequest authRequest) {
    	   System.out.println("Received request: " + authRequest);
    	    System.out.println("Username: " + authRequest.getEmail());
    	    System.out.println("Password: " + authRequest.getPassword());    
    	    
    	    //Creates an authentication request (UsernamePasswordAuthenticationToken) with the provided email and password.
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getEmail(), authRequest.getPassword())
        );
        
    	System.out.println("hi1");

        
        System.out.println(authRequest.getEmail()+ "between " + authRequest.getPassword());

        //Retrieves authenticated user details from the Authentication object.
        // Authentication is interface which implements principal and Serializable  
        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        
        //Calls jwtService.generateToken(username) to create a JWT for the authenticated user.
        String jwtToken = jwtService.generateToken(userDetails.getUsername());

        return ResponseEntity.ok(new AuthResponse(jwtToken));
    }
}

