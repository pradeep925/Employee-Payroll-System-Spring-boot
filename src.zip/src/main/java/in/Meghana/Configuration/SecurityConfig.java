package in.Meghana.Configuration;

import in.Meghana.JwtUtil.JwtAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.util.List;

@Configuration
@EnableMethodSecurity 

public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;  
    private final UserDetailsService userDetailsService;  //load user details

    //constructor
    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter, UserDetailsService userDetailsService) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
        this.userDetailsService = userDetailsService;
    }

    //define security setting for http request and HttpSecurity used to config authontication rules
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        //Cross-Site Request Forgery  Disables CSRF protection since JWT is stateless and doesn’t use sessions.

    	http .csrf(csrf -> csrf.disable())  
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/auth/login").permitAll()  // Allow login API without authentication
                        .requestMatchers("/api/users/register").permitAll() 
                        .requestMatchers("/api/users/all").hasAnyRole("ADMIN")  // Both ADMIN and USER can view users
                        .requestMatchers("/api/users/delete").hasRole("ADMIN")  // Only ADMIN can delete users
                        .requestMatchers("/api/users/update/").hasAnyRole("ADMIN","USER")
                        .requestMatchers("/api/users/profile/").hasAnyRole("ADMIN","USER")
                       //.requestMatchers("/salary/**").permitAll()
                        .requestMatchers("/salary/get/**").hasAnyRole("USER","ADMIN")
                       .requestMatchers("/salary/add/**").hasAnyRole("ADMIN")
                        
                        .anyRequest().authenticated()  // All other requests require authentication
                )
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS)) // Stateless session (for JWT)
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class); // Add JWT filter
//this is like we normally add the user name and the password which is normally generated instead of that we 
    	//can add this the jwt authrntication 
        return http.build();  //return security config
    }

    @Bean
    //AuthenticationManager is a class which is present spring frame work package which is uses to authenticate the password
    public AuthenticationManager authenticationManager() {
    	//  DaoAuthenticationProvider is a class which extends AbstractUserDetailsAuthenticationProvider.
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return new ProviderManager(List.of(authProvider));
    }

    @Bean
    // PasswordEncoder is a interface 
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
        // BCryptPasswordEncoder is a class which implements passwordEncoder 
    }
}
